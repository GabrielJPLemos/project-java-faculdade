package com.java.project.faculdade;

public class Main extends AcoesGerais {
	
	public static void main(String[] args) {	
		menu();
	}
}
