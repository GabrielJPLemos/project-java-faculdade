package com.java.project.faculdade;

public class Provas{
	
	
	private int pontuacao;
	
	public Provas() {
		
	}
	
	public Provas(int pontuacao) {
		this.pontuacao = pontuacao;
	}

	public int getPontuacao() {
		return pontuacao;
	}
	public void setPontuacao(int pontuacao) {
		this.pontuacao = pontuacao;
	}
	
}
