# project-java-faculdade
Pequeno projeto em java com poo, simulando o funcionamento de um sistema de faculdade
